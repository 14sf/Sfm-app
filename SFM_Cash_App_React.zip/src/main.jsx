
import React from 'react';
import ReactDOM from 'react-dom/client';

function App() {
  return (
    <div>
      <h1>Bienvenue sur SFM Cash 🚀</h1>
      <p>Votre assistant financier complet.</p>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
